'use strict';

module.exports = {
  'typeof': require('./typeof'),
  'instanceof': require('./instanceof'),
  range: require('./range'),
  propertyNames: require('./propertyNames'),
  regexp: require('./regexp')
};
