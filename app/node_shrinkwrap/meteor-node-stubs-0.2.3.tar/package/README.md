# node-stubs
Stub implementations of Node built-in modules, a la Browserify
