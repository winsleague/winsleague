. "$1"

printenv
