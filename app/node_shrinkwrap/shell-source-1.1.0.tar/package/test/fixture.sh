export ENV_VAR1="one"
export ENV_VAR2="two"
export PATH="node_modules/.bin:$PATH"
