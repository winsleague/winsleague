'use strict';

var isImplemented = require('../../../../array/#/map/is-implemented');

module.exports = function (a) { a(isImplemented(), true); };
