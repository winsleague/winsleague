'use strict';

module.exports = require('../values/shim');
