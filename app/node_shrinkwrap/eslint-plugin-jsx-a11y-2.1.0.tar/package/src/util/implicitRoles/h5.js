/**
 * Returns the implicit role for an h5 tag.
 */
export default function getImplicitRoleForH5() {
  return 'heading';
}
