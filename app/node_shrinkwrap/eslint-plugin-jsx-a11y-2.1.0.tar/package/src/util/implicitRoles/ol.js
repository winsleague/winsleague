/**
 * Returns the implicit role for an ol tag.
 */
export default function getImplicitRoleForOl() {
  return 'list';
}
