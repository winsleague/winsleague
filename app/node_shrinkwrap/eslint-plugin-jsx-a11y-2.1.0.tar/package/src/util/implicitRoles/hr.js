/**
 * Returns the implicit role for an hr tag.
 */
export default function getImplicitRoleForHr() {
  return 'separator';
}
