/**
 * Returns the implicit role for an h6tag.
 */
export default function getImplicitRoleForH6() {
  return 'heading';
}
