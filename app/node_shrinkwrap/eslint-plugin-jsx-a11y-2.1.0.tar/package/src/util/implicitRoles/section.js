/**
 * Returns the implicit role for a section tag.
 */
export default function getImplicitRoleForSection() {
  return 'region';
}
