/**
 * Returns the implicit role for a body tag.
 */
export default function getImplicitRoleForBody() {
  return 'document';
}
