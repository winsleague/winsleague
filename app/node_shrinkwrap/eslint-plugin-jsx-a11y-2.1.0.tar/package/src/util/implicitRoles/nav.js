/**
 * Returns the implicit role for a nav tag.
 */
export default function getImplicitRoleForNav() {
  return 'navigation';
}
