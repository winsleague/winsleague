/**
 * Returns the implicit role for a ul tag.
 */
export default function getImplicitRoleForUl() {
  return 'list';
}
