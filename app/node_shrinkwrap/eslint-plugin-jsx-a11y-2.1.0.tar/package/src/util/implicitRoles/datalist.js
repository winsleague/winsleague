/**
 * Returns the implicit role for a datalist tag.
 */
export default function getImplicitRoleForDatalist() {
  return 'listbox';
}
