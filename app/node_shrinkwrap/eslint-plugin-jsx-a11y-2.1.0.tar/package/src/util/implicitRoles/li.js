/**
 * Returns the implicit role for an li tag.
 */
export default function getImplicitRoleForLi() {
  return 'listitem';
}
