/**
 * Returns the implicit role for an output tag.
 */
export default function getImplicitRoleForOutput() {
  return 'status';
}
