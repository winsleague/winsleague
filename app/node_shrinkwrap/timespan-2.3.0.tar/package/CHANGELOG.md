#VERSION HISTORY

##2.0 
* [Breaking] Refactored this to work in node.js. Backwards compatibility to existing browser API coming in future 2.x releases. (indexzero)

## 1.2
* Added TimeSpan.FromDates Constructor to take two dates
  and create a TimeSpan from the difference. (mstum)

## 1.1
* Changed naming to follow JavaScript standards (mstum)
* Added Documentation (mstum)

## 1.0
* Initial Revision (mstum)
