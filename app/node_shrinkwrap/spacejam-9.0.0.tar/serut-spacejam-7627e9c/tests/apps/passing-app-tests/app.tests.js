import {expect} from "meteor/practicalmeteor:chai"

describe("Test", ()=>{

  it("This unit test should pass", ()=>{
    expect(true).to.be.true
  })

});

