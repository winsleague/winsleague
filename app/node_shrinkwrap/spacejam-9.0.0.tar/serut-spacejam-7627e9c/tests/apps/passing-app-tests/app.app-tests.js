import {expect} from "meteor/practicalmeteor:chai"

describe("Test", ()=>{

  it("This app test should pass", ()=>{
    expect(true).to.be.true
  })

});

