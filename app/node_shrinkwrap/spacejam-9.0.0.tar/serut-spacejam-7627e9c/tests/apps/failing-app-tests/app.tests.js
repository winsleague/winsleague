import {expect} from "meteor/practicalmeteor:chai"

describe("Test", ()=>{

  it("This unit test should fail", ()=>{
    expect(true).to.be.false
  })

});

