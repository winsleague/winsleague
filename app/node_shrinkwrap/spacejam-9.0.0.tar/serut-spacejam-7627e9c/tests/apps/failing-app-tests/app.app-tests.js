import {expect} from "meteor/practicalmeteor:chai"

describe("Test", ()=>{

  it("This app test should fail", ()=>{
    expect(true).to.be.false
  })

});

