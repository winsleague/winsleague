1. The whole API is public.  No underscore-prefixed pretend-private
   things or hidden Object.create magic mumbo jumbo here.  Plain old
   objects that are created from constructors.
2. 100% test coverage must be maintained.
