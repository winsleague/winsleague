/**
 * Returns the implicit role for an option tag.
 */
export default function getImplicitRoleForOption() {
  return 'option';
}
