/**
 * Returns the implicit role for a form tag.
 */
export default function getImplicitRoleForForm() {
  return 'form';
}
