/**
 * Returns the implicit role for a dialog tag.
 */
export default function getImplicitRoleForDialog() {
  return 'dialog';
}
