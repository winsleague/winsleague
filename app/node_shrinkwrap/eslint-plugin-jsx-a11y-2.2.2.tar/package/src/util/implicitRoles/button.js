/**
 * Returns the implicit role for a button tag.
 */
export default function getImplicitRoleForButton() {
  return 'button';
}
