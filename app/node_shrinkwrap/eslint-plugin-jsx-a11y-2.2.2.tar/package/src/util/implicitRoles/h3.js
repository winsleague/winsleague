/**
 * Returns the implicit role for an h3 tag.
 */
export default function getImplicitRoleForH3() {
  return 'heading';
}
