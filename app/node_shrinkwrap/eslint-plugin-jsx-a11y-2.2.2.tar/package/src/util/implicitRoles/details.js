/**
 * Returns the implicit role for a details tag.
 */
export default function getImplicitRoleForDetails() {
  return 'group';
}
