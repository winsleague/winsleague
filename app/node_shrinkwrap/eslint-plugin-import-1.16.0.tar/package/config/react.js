/**
 * - adds `.jsx` as an extension
 */
module.exports = {
  settings: {
    'import/extensions': ['.js', '.jsx'],
  },
}
