#!/usr/bin/env bash
set -eu

npm run test-node
npm run test-headless